CREATE PROCEDURE AjouterJourneeTravail (
  p_codeSalarie TRAVAILLER.codeSalarie%TYPE,
  p_codeProjet TRAVAILLER.codeProjet%TYPE,
  p_dateTravail Travailler.DATETRAVAIL%TYPE
) IS
    vb NUMBER;
  BEGIN
    SELECT count(CODESALARIE) into vb
    FROM PROJETS P
    JOIN ETREAFFECTE E ON E.CODEEQUIPE=P.CODEEQUIPE
    WHERE P.CODEPROJET=p_codeProjet AND e.CODESALARIE=p_codeSalarie;
    if vb=0 THEN
    INSERT INTO TRAVAILLER VALUES (p_codeSalarie,p_dateTravail,p_codeProjet);
    UPDATE SALARIES
      SET NBTOTALJOURNEESTRAVAIL=NBTOTALJOURNEESTRAVAIL+1;
    END IF;
    EXCEPTION
    WHEN No_data_found THEN
    RAISE_APPLICATION_ERROR(-20001,'Le salarié doit faire partie de l équipe qui réalise le projet');
  END;
/
