CREATE PROCEDURE AffecterSalarieEquipe (
  p_codeSalarie ETREAFFECTE.codeSalarie%TYPE,
  p_codeEquipe ETREAFFECTE.codeEquipe%TYPE
) IS
    v_nbAffectation NUMBER;
    Erreur EXCEPTION;
  BEGIN
    SELECT count(codeSalarie) INTO v_nbAffectation
    FROM ETREAFFECTE
    WHERE CODESALARIE=p_codeSalarie;
    IF v_nbAffectation<3 THEN
      INSERT INTO ETREAFFECTE VALUES (p_codeSalarie,p_codeEquipe);
      ELSE
      RAISE Erreur;
    END IF;
    EXCEPTION
    WHEN Erreur THEN
      RAISE_APPLICATION_ERROR(-20001, 'Le salarié est déjà affecté à au moins 3 équipes');
  END;
/
