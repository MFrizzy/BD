CREATE TRIGGER PLUSTROISEQUIPES
BEFORE INSERT
  ON ETREAFFECTE
FOR EACH ROW
  DECLARE
    v_nbAffectation NUMBER;
  BEGIN
    SELECT count(codeSalarie) INTO v_nbAffectation
    FROM ETREAFFECTE
    WHERE CODESALARIE=:NEW.codeSalarie;
    IF v_nbAffectation>=3 THEN
      RAISE_APPLICATION_ERROR(-20001, 'Le salarié est déjà affecté à au moins 3 équipes');
    END IF;
  END;
/
